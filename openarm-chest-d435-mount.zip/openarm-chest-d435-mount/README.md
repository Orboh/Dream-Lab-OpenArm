# OpenArm chest-post D435 mount — elevated, 0–45° tilt

## What's in this package

```
1-fixed-height/   riser + cradle, camera at 145 mm, no adjustment
2-tall-variants/  riser at 260 mm (bolted the whole way up)
                  riser at 300 mm, deep-channel mast (post ends at 130 mm)
3-telescoping/    base rail + slider + cradle, 54 mm of stepless travel
src/              the two CadQuery scripts that generate all of the above
previews/         renders and annotated sections
reference/        Enactic's own chest bracket, for comparison (CERN-OHL-S-2.0)
```

Pick ONE of folders 1-3. They all use the same cradle design and the same
D435 interface; they differ only in how the height is set.

| | height | adjustment | parts | total print |
|---|---|---|---|---|
| 1-fixed-height | 145 mm | 40 mm via post T-nuts | 2 | 101 cm³ |
| 2-tall-variants | 260 / 300 mm | post T-nuts only | 2 | 164 / 277 cm³ |
| 3-telescoping | 146-200 mm | 54 mm stepless, on the slide | 3 | 265 cm³ |

Every part below was checked in CAD for zero interference across the full
0-45° tilt range, and the telescoping pair was additionally checked for free
travel, dovetail capture, clamp-screw reach and bolt access.


Two printed parts that bolt to the OpenArm chest post (60×60 T-slot extrusion)
and carry an Intel RealSense D435 on an adjustable pivot.

```
openarm_chest_d435_riser.step / .stl    42 × 66 × 156 mm   80.0 cm³
openarm_chest_d435_cradle.step / .stl   33 × 53 × 39 mm    21.4 cm³
openarm_chest_mount.py                  parametric source (CadQuery)
```

## Angle convention

`tilt = 0°`  — camera plate parallel to the vertical plane, optical axis
horizontal.
`tilt = 45°` — pitched 45° nose-down.

The arc slot gives exactly 45° of continuous travel, lockable anywhere in
between. Tick marks at 0 / 15 / 30 / 45° are engraved 0.8 mm deep on the outer
face of each ear, read against the lock bolt.

## Interfaces

| Interface | Spec |
|---|---|
| Post | 4 × vertical slots, Ø6.6, 30 mm pitch, two banks (z 20–60 and 78–118) |
| Height trim | 40 mm of travel in the slots |
| Pivot | Ø5.3 through, at 20 mm forward / 145 mm above the plate bottom |
| Tilt lock | Ø5.4 arc slot, 21 mm centreline radius, −45° to −90° |
| Camera | 2 × Ø3.4 at 45 mm pitch, plus Ø6.8 central 1/4-20 clearance |
| Overall width | 66 mm (pivot and lock bolts pass right through) |
| Camera plate at 0° | 40 mm forward of the post face |

## Hardware

- 4 × M6 T-slot nuts + M6×16 button head — post
- 1 × M5×80 socket head + nyloc — pivot
- 1 × M5×80 + star knob or wing nut — tilt lock (tool-free adjustment)
- 2 × M3×6 — D435 to the camera plate

For M8 T-nuts set `POST_BOLT_D = 8.6` and re-run the script.

## Printing

Riser: lay the base plate flat on the bed (the X=0 face down). The ears and
ribs then point up; light support under the pivot boss only.
Cradle: camera plate flat on the bed, no support.

0.2 mm layers, 4 perimeters, 40% infill. PETG or ASA preferred over PLA if the
arm runs warm — the lock relies on clamping friction between the ear and the
cradle side plate, and PLA creeps.

## Regenerating / changing the height

```
pip install cadquery
python openarm_chest_mount.py
```

`PIVOT_Z` is the single height knob — the camera height above the bottom of
the plate. `BASE_H`, the rib height and the number of T-slot bolt banks all
derive from it, so the plate stays bolted to the post to within ~25 mm of the
pivot at any height and the unsupported overhang never grows:

| PIVOT_Z | plate | bolt banks | T-nuts | overhang | riser volume |
|---|---|---|---|---|---|
| 145 mm | 130 mm | 2 | 4 | 27 mm | 80.0 cm³ |
| 200 mm | 185 mm | 3 | 6 | 24 mm | 109.6 cm³ |
| 260 mm | 245 mm | 4 | 8 | 26 mm | 142.3 cm³ |
| 320 mm | 305 mm | 5 | 10 | 28 mm | 174.9 cm³ |
| 400 mm | 385 mm | 7 | 14 | 23 mm | 217.2 cm³ |

Either edit the constant or set it per run:

```
OPENARM_PIVOT_Z=260 python openarm_chest_mount.py
```

This only works while the post is tall enough to bolt into. Above the top of
the post the plate becomes a real cantilever and the 8 mm × 66 mm section is
no longer the right shape for the job.

Other useful constants: `TILT_MAX` (tilt range), `R_LOCK` (arc radius),
`POST_BOLT_D` (8.6 for M8 T-nuts), and the `CAM_*` group for a different
RealSense body.

The script also verifies itself: `build_riser()` and `build_cradle()` can be
intersected across the tilt range to confirm zero interference. Checked at 0,
145 and 260 mm — 0 mm³ at every 5° step from 0 to 45.

## Cantilever mode (post does not reach)

If the post stops below the camera, everything above the top bolt is an
unsupported mast and the flat 8 mm plate is the wrong section. Set `POST_TOP`
to the boltable height and turn on `DEEP_CHANNEL`, which runs the clevis ears
down the full length as flanges:

```
OPENARM_PIVOT_Z=300 OPENARM_POST_TOP=130 OPENARM_DEEP=1 python openarm_chest_mount.py
```

Measured at z = 200 mm (above the post), camera at 300 mm, 182 mm unsupported:

| section | area | I | k | sag at 1 g | f1 |
|---|---|---|---|---|---|
| flat plate + small ribs | 624 mm² | 8 527 mm⁴ | 7.6 N/mm | 0.092 mm | 52 Hz |
| deep channel | 936 mm² | 143 618 mm⁴ | 128.6 N/mm | 0.005 mm | 213 Hz |

17× the stiffness for 50% more material, and it still prints with no support:
lay the web flat on the bed, flanges pointing up.

Caveats: these treat the root as rigid. At 180 mm of lever arm the bolted
joint, not the section, sets real behaviour — use the full available post
length for the bolt span and preload the T-nuts properly. For masts much
longer than this, bolt on a length of 20×40 aluminium extrusion and print
only the end fittings; roughly 10× stiffer again than the printed channel.

## Telescoping version (height-adjustable slide)

`openarm_chest_slider.py` builds a three-part version where the height is set
by sliding, not by reprinting.

```
openarm_slide_base_rail.step / .stl    18 × 66 × 130 mm    73.2 cm³
openarm_slide_slider.step   / .stl     50 × 66 × 151 mm   170.4 cm³
openarm_slide_cradle.step   / .stl     unchanged          21.4 cm³
```

**Travel: 54 mm, stepless.** Camera sits anywhere from 146 to 200 mm, on top
of the coarse positions the post T-nuts already give. A 10 mm scale is
engraved on the tongue so a setting can be repeated.

### How it holds

A dovetail tongue on the rail, narrow at its root and wide at its tip, so the
slider's lips hook under it and it cannot be pulled off forward. Outside the
dovetail the slider bears flat on the rail's front face across the full 66 mm
width, and that flat contact carries the bending moment; the dovetail only
stops lift-off. Two M5 screws pass through the slider's web into two plain M5
hex nuts held captive in a channel up the middle of the tongue.

### Built-in stoppers

- **Lower:** the nut channel is blind at z = 16 mm, so the nuts cannot run out
  of the bottom.
- **Upper:** the nuts are loaded through a port at the top of the tongue, then
  an M3 keeper screw goes in below it at z = 108 mm and blocks the way back.

With the keeper fitted the slider is captive on the rail at both ends of
travel even with the clamp screws fully loose.

### Hardware

- 4 × M6 T-slot nuts + M6×16 **button head** (post — button heads and a hex
  key both clear the tongue; socket caps do not)
- 2 × M5 plain hex nuts (captive) + 2 × M5×12 socket head (clamp)
- 1 × M3×8 (keeper)
- 1 × M5×80 + nyloc (pivot), 1 × M5×80 + knob (tilt lock)
- 2 × M3×6 (D435)

### Assembly order

1. Bolt the base rail to the post, slider off.
2. Drop the two M5 nuts into the port at the top of the tongue, slide them down.
3. Fit the M3 keeper screw below the port.
4. Slide the slider on from the top.
5. Fit the two M5 clamp screws through the web into the nuts.
6. Set the height against the scale and tighten.

### Printing in PLA

PLA suits this well — measured on the slider's own section, it is about 1.7×
stiffer than PETG (f1 922 Hz vs 714 Hz). Two cautions: PLA softens from around
55–60 °C, so keep it away from warm motors, and it creeps under sustained
clamp load, so do not over-torque the M5 screws and re-check them after a few
weeks.

Orientations, all support-free:

- **Base rail** — back face on the bed, tongue pointing up. The dovetail
  flanks sit at about 22° from vertical and the nut slot steps in by 1.3 mm
  a side, both of which print unsupported.
- **Slider** — on its side, one flange face on the bed, with a brim. This also
  runs the layers along the length, so bending tension is carried by filament
  rather than across layer lines.
- **Cradle** — camera plate on the bed.

`FIT = 0.35` is the per-side sliding clearance. Print a 20 mm test slice of
the rail and a short slider stub first and tune it before committing to the
full parts. Scrape or chamfer the first-layer elephant's foot on the dovetail,
or the slide will bind at the bed side.

## Provenance

Post interface dimensions (60×60 extrusion, 30 mm T-slot pitch) and the D435
45 mm hole pitch follow the OpenArm chest camera bracket documented in
`SeongminJaden/openarm-bimanual-setup`, which in turn mesh-exports the Enactic
`openarm_hardware` CAD. The geometry here is original, not a derivative of the
Enactic STEP — but if you merge any of their CAD into it, CERN-OHL-S-2.0
applies to the result.
