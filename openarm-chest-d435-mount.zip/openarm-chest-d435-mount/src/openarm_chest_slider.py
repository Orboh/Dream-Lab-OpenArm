"""
OpenArm chest mount - telescoping height-adjustable version, for PLA.

Three printed parts:
  base_rail  - bolts to the 60x60 chest post, carries a dovetail tongue with
               a captive M5 nut channel running up its centre
  slider     - female dovetail, deep flanges, clevis at the top; clamps to
               the rail anywhere in the travel with two M5 screws
  cradle     - unchanged from the fixed-height version

Built-in stoppers: the nut channel is blind at the bottom and blocked at the
top by an M3 keeper screw fitted after the nuts are loaded, so the slider
physically cannot run off either end of the rail.

Everything prints without support in the orientations noted in the README.
"""
import os, math

os.environ.setdefault("OPENARM_PIVOT_X", "36.0")
os.environ.setdefault("OPENARM_PIVOT_Z", "146.0")

import cadquery as cq
import openarm_chest_mount as M
from openarm_chest_mount import xz, disc, band, P, BASE_W, BASE_T, EAR_T, \
    EAR_YIN, BOSS_R, BAND_RI, BAND_RO, R_LOCK, LOCK_A0, TILT_MAX, \
    BOLT_PIVOT_D, BOLT_LOCK_D, POST_SLOT_PITCH, POST_BOLT_D

# ----------------------------------------------------------------- base rail
BASE_H   = 130.0            # bolted length on the post
TONG_X0, TONG_X1 = 8.0, 18.0
# Dovetail half-widths. NARROW at the root, WIDE at the free end -- that way
# the slider's lips hook under the tongue and it cannot be pulled off
# forward. Kept slim so the post bolt heads either side stay reachable.
TONG_WIN, TONG_WOUT = 7.0, 11.0     # root (x0) / free end (x1)
TONG_Z0, TONG_Z1 = 10.0, 126.0

CH_X0, CH_X1 = 10.0, 14.4   # M5 nut pocket
CH_HY        = 4.3
SLOT_HY      = 3.0          # screw slot through the tongue face
CH_Z0, CH_Z1 = 16.0, 126.0
PORT_Z0      = 112.0        # nuts drop in here
KEEP_Z       = 108.0        # M3 keeper screw blocks them coming back
KEEP_D       = 2.6          # self-tapping pilot in PLA

# -------------------------------------------------------------------- slider
FIT        = 0.35           # per-side sliding clearance on the dovetail
WEB_X0, WEB_X1 = 18.0, 24.0
FLANGE_X1  = 52.0
SLIDER_H   = 150.0
SLIDER_Z0  = 6.0            # bottom of the slider at the lowest setting
CLAMP_DZ   = 30.0           # screw spacing
CLAMP_Z    = (14.0, 14.0 + CLAMP_DZ)   # slider-local
CLAMP_D    = 5.4
CLAMP_CB_D, CLAMP_CB_X = 9.6, 4.0      # counterbore for M5 socket heads

# travel is set by the upper screw reaching the keeper, with the lower screw
# never dropping below the blind bottom of the nut channel
TRAVEL = (KEEP_Z - 4.0) - (SLIDER_Z0 + CLAMP_Z[1])


def _dovetail(dy, x0=TONG_X0, x1=TONG_X1, z0=None, z1=None):
    """Dovetail prism, grown by dy on every face (dy=0 -> nominal tongue)."""
    z0 = TONG_Z0 if z0 is None else z0
    z1 = TONG_Z1 if z1 is None else z1
    a, b = TONG_WIN + dy, TONG_WOUT + dy
    pts = [(x0 - dy, -a), (x1 + dy, -b), (x1 + dy, b), (x0 - dy, a)]
    return (cq.Workplane("XY").workplane(offset=z0)
            .polyline(pts).close().extrude(z1 - z0))


def build_base_rail():
    r = cq.Workplane("XY").box(BASE_T, BASE_W, BASE_H,
                               centered=(False, True, False))
    r = r.union(_dovetail(0.0))

    for ysign in (-1, 1):
        y = ysign * POST_SLOT_PITCH / 2
        for z0, z1 in M.SLOT_SETS:
            r = r.cut(cq.Workplane("YZ").center(y, (z0 + z1) / 2)
                      .slot2D(z1 - z0 + POST_BOLT_D, POST_BOLT_D, 90)
                      .extrude(BASE_T + 4).translate((-2, 0, 0)))

    # captive nut channel + its screw slot, blind at the bottom
    r = r.cut(cq.Workplane("XY").workplane(offset=CH_Z0)
              .box(CH_X1 - CH_X0, 2 * CH_HY, CH_Z1 - CH_Z0,
                   centered=(False, True, False))
              .translate((CH_X0, 0, 0)))
    r = r.cut(cq.Workplane("XY").workplane(offset=CH_Z0)
              .box(TONG_X1 + 0.5 - CH_X1, 2 * SLOT_HY, CH_Z1 - CH_Z0,
                   centered=(False, True, False)).translate((CH_X1, 0, 0)))
    # loading port
    r = r.cut(cq.Workplane("XY").workplane(offset=PORT_Z0)
              .box(TONG_X1 + 0.5 - CH_X1, 2 * (CH_HY + 0.3), CH_Z1 - PORT_Z0,
                   centered=(False, True, False)).translate((CH_X1, 0, 0)))
    # keeper screw
    r = r.cut(cq.Workplane("YZ").center(0, KEEP_Z).circle(KEEP_D / 2)
              .extrude(TONG_X1 - 9.0).translate((9.0, 0, 0)))

    # 10 mm height scale on the tongue face
    for z in range(20, int(TONG_Z1) - 8, 10):
        long = (z % 50 == 0)
        r = r.cut(cq.Workplane("XY").workplane(offset=z - 0.6)
                  .box(0.8, (6.0 if long else 3.5), 1.2,
                       centered=(False, True, False))
                  .translate((TONG_X1 - 0.8, SLOT_HY + 1.0, 0)))
    return r


def build_slider():
    s = cq.Workplane("XY").workplane(offset=SLIDER_Z0).box(
        TONG_X1 - TONG_X0, BASE_W, SLIDER_H,
        centered=(False, True, False)).translate((TONG_X0, 0, 0))
    s = s.union(cq.Workplane("XY").workplane(offset=SLIDER_Z0).box(
        WEB_X1 - WEB_X0, BASE_W, SLIDER_H,
        centered=(False, True, False)).translate((WEB_X0, 0, 0)))

    # deep flanges -> stiff channel section
    for ysign in (-1, 1):
        y0 = ysign * EAR_YIN if ysign > 0 else -EAR_YIN - EAR_T
        s = s.union(xz([(WEB_X1 - 0.2, SLIDER_Z0 + 4),
                        (FLANGE_X1, SLIDER_Z0 + 22),
                        (FLANGE_X1, M.PIVOT_Z - 34.0),
                        (WEB_X1 - 0.2, M.PIVOT_Z - 10.0)], EAR_T, y0))

    # clevis ears
    for ysign in (-1, 1):
        y0 = ysign * EAR_YIN if ysign > 0 else -EAR_YIN - EAR_T
        ear = disc(*P(0, 0), BOSS_R, EAR_T, y0)
        ear = ear.union(xz([P(*p) for p in band(BAND_RI, BAND_RO, -38, -97)],
                           EAR_T, y0))
        ear = ear.union(xz([P(-22, -40), P(4, -40), P(4, -8), P(-22, -8)],
                           EAR_T, y0))
        s = s.union(ear)

    # female dovetail, running the full height of the slider
    s = s.cut(_dovetail(FIT, z0=SLIDER_Z0 - 1, z1=SLIDER_Z0 + SLIDER_H + 1))

    # clamp screws, counterbored from the front
    for dz in CLAMP_Z:
        z = SLIDER_Z0 + dz
        s = s.cut(cq.Workplane("YZ").center(0, z).circle(CLAMP_D / 2)
                  .extrude(60).translate((0, 0, 0)))
        s = s.cut(cq.Workplane("YZ").center(0, z).circle(CLAMP_CB_D / 2)
                  .extrude(CLAMP_CB_X).translate((WEB_X1 - CLAMP_CB_X, 0, 0)))

    # pivot + arc slot, same as the fixed version
    s = s.cut(disc(*P(0, 0), BOLT_PIVOT_D / 2, 200, -100))
    a_end = LOCK_A0 - TILT_MAX
    for ysign in (-1, 1):
        y0 = (EAR_YIN - 1) if ysign > 0 else -EAR_YIN - EAR_T - 1
        s = s.cut(xz([P(*p) for p in
                      band(R_LOCK - BOLT_LOCK_D / 2, R_LOCK + BOLT_LOCK_D / 2,
                           LOCK_A0, a_end)], EAR_T + 2, y0))
        for a in (LOCK_A0, a_end):
            s = s.cut(disc(*P(R_LOCK * math.cos(math.radians(a)),
                              R_LOCK * math.sin(math.radians(a))),
                           BOLT_LOCK_D / 2, EAR_T + 2, y0))
    return s


def lift(shape, dz):
    return shape.translate((0, 0, dz))


if __name__ == "__main__":
    out = "/home/claude/out"
    rail, sl = build_base_rail(), build_slider()
    cradle = M.build_cradle()
    for name, s in (("base_rail", rail), ("slider", sl)):
        cq.exporters.export(s, f"{out}/openarm_slide_{name}.step")
        cq.exporters.export(s, f"{out}/openarm_slide_{name}.stl",
                            tolerance=0.05, angularTolerance=0.1)
        b = s.val().BoundingBox()
        print(f"{name:10s} {b.xlen:6.1f} x {b.ylen:6.1f} x {b.zlen:6.1f} mm"
              f"   vol {s.val().Volume()/1000:6.1f} cm3")
    print(f"\nPIVOT_X = {M.PIVOT_X}  PIVOT_Z(lowest) = {M.PIVOT_Z}")
    print(f"slide travel = {TRAVEL:.0f} mm "
          f"-> camera {M.PIVOT_Z:.0f} to {M.PIVOT_Z + TRAVEL:.0f} mm")
    print(f"post bolt banks: {M.SLOT_SETS}")
