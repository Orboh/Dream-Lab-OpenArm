"""
OpenArm chest-post RealSense D435 mount - elevated, tilt-adjustable 0-45 deg.

Two printed parts:
  riser.step/.stl   - bolts to the 60x60 T-slot chest post, carries the clevis
  cradle.step/.stl  - holds the D435, pivots in the clevis, locked by an arc slot

Angle convention: TILT = 0 deg  -> camera face plate parallel to the vertical
plane (optical axis horizontal). TILT = 45 deg -> pitched 45 deg nose-down.
"""
import math
import cadquery as cq

# ----------------------------------------------------------------- parameters
# Post interface (from OpenArm chest post: 60x60 extrusion, 30 mm T-slot pitch)
POST_SLOT_PITCH = 30.0
POST_BOLT_D     = 6.6     # M6 clearance; use 8.6 for M8 T-nuts
BASE_W = 66.0    # plate width (post is 60; ears sit flush with the edges)
BASE_T = 8.0     # plate thickness

# Clevis / pivot
PIVOT_X = float(__import__("os").environ.get("OPENARM_PIVOT_X", 20.0))
# ---- THE HEIGHT KNOB -------------------------------------------------------
# PIVOT_Z is the camera height above the bottom of the plate. Everything that
# has to move with it is derived below, so this is the only number to change.
# Raising it lengthens the bolted-down plate, it does NOT lengthen the
# unsupported overhang -- see WEB_GAP.
PIVOT_Z = float(__import__("os").environ.get("OPENARM_PIVOT_Z", 145.0))

WEB_GAP   = 15.0   # pivot above the plate top; the ear web bridges this
SLOT_LEN  = 40.0   # travel per slot (height trim)
SLOT_Z0   = 20.0   # first slot bank starts here
SLOT_STEP = 58.0   # bank pitch up the plate

BASE_H = PIVOT_Z - WEB_GAP

# ---- CANTILEVER MODE -------------------------------------------------------
# POST_TOP is how far up the post there is still extrusion to bolt into.
# Leave it >= BASE_H and the plate is supported all the way (the cheap case).
# Set it lower and everything above it is an unsupported mast, so the section
# has to carry the moment on its own -> turn DEEP_CHANNEL on, which runs the
# clevis ears all the way down as a pair of deep flanges.
POST_TOP = float(__import__("os").environ.get("OPENARM_POST_TOP", 1e9))
DEEP_CHANNEL = __import__("os").environ.get("OPENARM_DEEP", "0") == "1"
CHEEK_X1 = 42.0   # how far forward the flanges reach


def _slot_banks():
    """Bolt banks up the whole plate, so the overhang never grows."""
    top = min(BASE_H, POST_TOP) - 8.0
    banks, z = [], SLOT_Z0
    while z + SLOT_LEN <= top:
        banks.append((z, z + SLOT_LEN))
        z += SLOT_STEP
    # close a large gap at the top so the overhang never grows with height
    if banks and top - banks[-1][1] > 12.0:
        banks.append((top - SLOT_LEN, top))
    return banks


SLOT_SETS = _slot_banks()
R_LOCK  = 21.0   # arc-slot centreline radius
TILT_MIN, TILT_MAX = 0.0, 45.0
LOCK_A0 = -45.0  # static-frame angle of the lock bolt at TILT = 0

EAR_T    = 6.0
EAR_YIN  = 27.0                  # inner face of each ear
BOSS_R   = 11.0
BAND_RI, BAND_RO = 15.0, 28.0    # arc-band inner/outer radius

BOLT_PIVOT_D = 5.3   # M5 clearance
BOLT_LOCK_D  = 5.4

# Cradle
SIDE_T   = 9.0
SIDE_YIN = 17.6                  # inner face of each cradle side plate
PLATE_X0, PLATE_X1 = 14.0, 20.0  # camera plate, pivot-local
PLATE_HZ = 16.0
PLATE_HY = 26.7

# Intel RealSense D435 rear mounting pattern
CAM_M3_PITCH = 45.0
CAM_M3_D     = 3.4
CAM_TRIPOD_D = 6.8   # 1/4-20 clearance

RIB_Y    = 25.0
RIB_T    = 6.0
RIB_X1   = 16.0
RIB_Z1   = BASE_H - 20.0


# ------------------------------------------------------------------- helpers
def xz(profile, t, y0):
    """Extrude a closed (x, z) profile by t, occupying Y in [y0, y0+t]."""
    return (cq.Workplane("XZ").polyline(profile).close()
            .extrude(t).translate((0, y0 + t, 0)))


def disc(x, z, r, t, y0):
    return (cq.Workplane("XZ").center(x, z).circle(r)
            .extrude(t).translate((0, y0 + t, 0)))


def arc_pts(r, a0, a1, n=64):
    return [(r * math.cos(math.radians(a0 + (a1 - a0) * i / n)),
             r * math.sin(math.radians(a0 + (a1 - a0) * i / n)))
            for i in range(n + 1)]


def band(ri, ro, a0, a1):
    return arc_pts(ro, a0, a1) + list(reversed(arc_pts(ri, a0, a1)))


def hull2d(pts):
    pts = sorted(set((round(x, 5), round(y, 5)) for x, y in pts))
    def half(p):
        out = []
        for q in p:
            while len(out) > 1:
                (ax, ay), (bx, by) = out[-2], out[-1]
                if (bx - ax) * (q[1] - ay) - (by - ay) * (q[0] - ax) <= 0:
                    out.pop()
                else:
                    break
            out.append(q)
        return out
    return half(pts)[:-1] + half(list(reversed(pts)))[:-1]


def circle_pts(cx, cz, r, n=48):
    return [(cx + r * math.cos(2 * math.pi * i / n),
             cz + r * math.sin(2 * math.pi * i / n)) for i in range(n)]


def P(x, z):
    """pivot-local -> world"""
    return (x + PIVOT_X, z + PIVOT_Z)


LOCK_L = (R_LOCK * math.cos(math.radians(LOCK_A0)),
          R_LOCK * math.sin(math.radians(LOCK_A0)))


# --------------------------------------------------------------------- riser
def build_riser():
    r = cq.Workplane("XY").box(BASE_T, BASE_W, BASE_H,
                               centered=(False, True, False))

    if DEEP_CHANNEL:
        # Flanges in the ear planes, run full height: the section becomes a
        # deep channel instead of a flat plate, which is what carries the
        # moment once the post stops supporting the back.
        for ysign in (-1, 1):
            y0 = ysign * EAR_YIN if ysign > 0 else -EAR_YIN - EAR_T
            r = r.union(xz([(BASE_T - 0.2, 6.0), (CHEEK_X1, 24.0),
                            (CHEEK_X1, PIVOT_Z - 34.0),
                            (BASE_T - 0.2, PIVOT_Z - 10.0)], EAR_T, y0))
    else:
        for ysign in (-1, 1):
            y0 = ysign * RIB_Y - RIB_T / 2
            r = r.union(xz([(BASE_T - 0.2, 8.0), (RIB_X1, 8.0),
                            (RIB_X1, RIB_Z1 - 14), (BASE_T - 0.2, RIB_Z1)],
                           RIB_T, y0))

    for ysign in (-1, 1):
        y0 = ysign * EAR_YIN if ysign > 0 else -EAR_YIN - EAR_T
        ear = disc(*P(0, 0), BOSS_R, EAR_T, y0)
        ear = ear.union(xz([P(*p) for p in band(BAND_RI, BAND_RO, -38, -97)],
                           EAR_T, y0))
        ear = ear.union(xz([P(-20, -40), P(4, -40), P(4, -8), P(-20, -8)],
                           EAR_T, y0))
        r = r.union(ear)

    # post slots
    for ysign in (-1, 1):
        y = ysign * POST_SLOT_PITCH / 2
        for z0, z1 in SLOT_SETS:
            slot = (cq.Workplane("YZ").center(y, (z0 + z1) / 2)
                    .slot2D(z1 - z0 + POST_BOLT_D, POST_BOLT_D, 90)
                    .extrude(BASE_T + 4).translate((-2, 0, 0)))
            r = r.cut(slot)

    # pivot hole (axis along Y, through both ears)
    px, pz = P(0, 0)
    r = r.cut(disc(px, pz, BOLT_PIVOT_D / 2, 200, -100))

    # arc slot through both ears
    a_end = LOCK_A0 - TILT_MAX
    slot_prof = (band(R_LOCK - BOLT_LOCK_D / 2, R_LOCK + BOLT_LOCK_D / 2,
                      LOCK_A0, a_end))
    for ysign in (-1, 1):
        y0 = (EAR_YIN - 1) if ysign > 0 else -EAR_YIN - EAR_T - 1
        r = r.cut(xz([P(*p) for p in slot_prof], EAR_T + 2, y0))
        for a in (LOCK_A0, a_end):
            cx = R_LOCK * math.cos(math.radians(a))
            cz = R_LOCK * math.sin(math.radians(a))
            r = r.cut(disc(*P(cx, cz), BOLT_LOCK_D / 2, EAR_T + 2, y0))

    # angle tick marks on the outer ear faces
    for ysign in (-1, 1):
        y0 = (EAR_YIN + EAR_T - 0.8) if ysign > 0 else -EAR_YIN - EAR_T
        for tilt in (0, 15, 30, 45):
            a = math.radians(LOCK_A0 - tilt)
            ca, sa = math.cos(a), math.sin(a)
            r0, r1 = (24.0, 27.6) if tilt in (0, 45) else (25.2, 27.6)
            w = 1.2
            quad = [(r0, -w / 2), (r1, -w / 2), (r1, w / 2), (r0, w / 2)]
            r = r.cut(xz([P(u * ca - v * sa, u * sa + v * ca)
                          for u, v in quad], 0.8, y0))
    return r


# -------------------------------------------------------------------- cradle
def build_cradle():
    prof = hull2d(circle_pts(0, 0, 10.0)
                  + circle_pts(LOCK_L[0], LOCK_L[1], 8.0)
                  + [(PLATE_X0 - 2, -PLATE_HZ), (PLATE_X1, -PLATE_HZ),
                     (PLATE_X1, PLATE_HZ), (PLATE_X0 - 2, PLATE_HZ)])

    c = None
    for ysign in (-1, 1):
        y0 = SIDE_YIN if ysign > 0 else -SIDE_YIN - SIDE_T
        s = xz([P(*p) for p in prof], SIDE_T, y0)
        c = s if c is None else c.union(s)

    plate = (cq.Workplane("XY")
             .box(PLATE_X1 - PLATE_X0, PLATE_HY * 2, PLATE_HZ * 2,
                  centered=(False, True, True))
             .translate((PIVOT_X + PLATE_X0, 0, PIVOT_Z)))
    c = c.union(plate)

    # pivot and lock bolts run along Y, through the side plates
    c = c.cut(disc(*P(0, 0), BOLT_PIVOT_D / 2, 200, -100))
    c = c.cut(disc(*P(*LOCK_L), BOLT_LOCK_D / 2, 200, -100))

    # D435 pattern in the camera plate
    cutter = (cq.Workplane("YZ").center(0, PIVOT_Z).circle(CAM_TRIPOD_D / 2)
              .extrude(40).translate((PIVOT_X + PLATE_X0 - 2, 0, 0)))
    for ysign in (-1, 1):
        cutter = cutter.union(
            cq.Workplane("YZ").center(ysign * CAM_M3_PITCH / 2, PIVOT_Z)
            .circle(CAM_M3_D / 2).extrude(40)
            .translate((PIVOT_X + PLATE_X0 - 2, 0, 0)))
    return c.cut(cutter)


def tilt(shape, deg):
    return shape.rotate((PIVOT_X, -1, PIVOT_Z), (PIVOT_X, 1, PIVOT_Z), deg)


if __name__ == "__main__":
    import os
    out = "/home/claude/out"
    os.makedirs(out, exist_ok=True)
    riser, cradle = build_riser(), build_cradle()
    for name, s in (("riser", riser), ("cradle", cradle)):
        cq.exporters.export(s, f"{out}/openarm_chest_d435_{name}.step")
        cq.exporters.export(s, f"{out}/openarm_chest_d435_{name}.stl",
                            tolerance=0.05, angularTolerance=0.1)
        b = s.val().BoundingBox()
        print(f"{name:7s} {b.xlen:7.2f} x {b.ylen:7.2f} x {b.zlen:7.2f} mm "
              f"  X[{b.xmin:.1f},{b.xmax:.1f}] Z[{b.zmin:.1f},{b.zmax:.1f}]")
    for d in (0, 45):
        cq.exporters.export(tilt(cradle, d),
                            f"{out}/_cradle_{d}.stl",
                            tolerance=0.05, angularTolerance=0.1)
    print("ok")
